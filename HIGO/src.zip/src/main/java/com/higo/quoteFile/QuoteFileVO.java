package com.higo.quoteFile;

public class QuoteFileVO {
	
	private String quoteFile_seq;
	private int gosu_seq;
	private int fileType_seq;
	private String quoteFile_name;
	
	
	public String getQuoteFile_seq() {
		return quoteFile_seq;
	}
	public void setQuoteFile_seq(String quoteFile_seq) {
		this.quoteFile_seq = quoteFile_seq;
	}
	public int getGosu_seq() {
		return gosu_seq;
	}
	public void setGosu_seq(int gosu_seq) {
		this.gosu_seq = gosu_seq;
	}
	public int getFileType_seq() {
		return fileType_seq;
	}
	public void setFileType_seq(int fileType_seq) {
		this.fileType_seq = fileType_seq;
	}
	public String getQuoteFile_name() {
		return quoteFile_name;
	}
	public void setQuoteFile_name(String quoteFile_name) {
		this.quoteFile_name = quoteFile_name;
	}
	
	
}
